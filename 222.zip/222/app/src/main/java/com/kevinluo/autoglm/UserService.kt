package com.kevinluo.autoglm

import android.app.Service
import android.content.Intent
import android.os.IBinder
import com.kevinluo.autoglm.util.Logger
import java.io.BufferedReader
import java.io.IOException
import java.io.InputStreamReader

/**
 * User service for executing shell commands with elevated privileges.
 * This service runs in a separate process with root permissions.
 */
class UserService : Service() {

    private val binder = object : IUserService.Stub() {
        override fun executeCommand(command: String): String {
            return try {
                val process = Runtime.getRuntime().exec(arrayOf("su", "-c", command))
                val reader = BufferedReader(InputStreamReader(process.inputStream))
                val errorReader = BufferedReader(InputStreamReader(process.errorStream))

                val output = StringBuilder()
                var line: String?

                while (reader.readLine().also { line = it } != null) {
                    output.append(line).append("\n")
                }

                val errorOutput = StringBuilder()
                while (errorReader.readLine().also { line = it } != null) {
                    errorOutput.append(line).append("\n")
                }

                val exitCode = process.waitFor()
                reader.close()
                errorReader.close()

                if (errorOutput.isNotEmpty()) {
                    output.append("\n[stderr]\n").append(errorOutput)
                }
                output.append("\n[exit code: $exitCode]")

                output.toString()
            } catch (e: IOException) {
                "Error: Root access denied or not available. Is the device rooted?\n${e.message}\n${e.stackTraceToString()}"
            } catch (e: Exception) {
                "Error: ${e.message}\n${e.stackTraceToString()}"
            }
        }

        override fun destroy() {
            Logger.i(TAG, "destroy command received")
            this@UserService.stopSelf()
        }
    }

    override fun onBind(intent: Intent?): IBinder {
        Logger.i(TAG, "onBind")
        return binder
    }

    override fun onCreate() {
        super.onCreate()
        Logger.i(TAG, "onCreate")
    }

    override fun onDestroy() {
        Logger.i(TAG, "onDestroy")
        super.onDestroy()
        // Exit the process when the service is destroyed to ensure a clean state
        System.exit(0)
    }

    companion object {
        private const val TAG = "UserService"
    }
}
