package com.kevinluo.autoglm

import io.kotest.core.spec.style.StringSpec
import io.kotest.matchers.shouldBe

/**
 * Example local unit test using Kotest, which will execute on the development machine (host).
 *
 * See [testing documentation](http://d.android.com/tools/testing).
 */
class ExampleUnitTest : StringSpec({
    "addition is correct" {
        (2 + 2) shouldBe 4
    }
})